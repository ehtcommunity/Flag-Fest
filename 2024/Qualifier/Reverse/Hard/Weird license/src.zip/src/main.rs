use chiprust_emu::Chip8;
use std::io::{self, BufRead, Write};

fn prompt_for_key() -> Vec<u8> {
    println!("Input your license key now.");
    print!("> ");
    io::stdout().flush().unwrap();

    let stdin = io::stdin();
    let mut iterator = stdin.lock().lines();
    let input = iterator.next().unwrap().unwrap();
    input.into_bytes()
}

fn main() {
    let key = prompt_for_key();

    let mut chip = Chip8::new
        ::<&'static (dyn Fn() -> u8 + Send + Sync + 'static),
        &'static (dyn Fn(u8) -> bool + Send + Sync + 'static)>
        (&|| 0, &|_| false);

    chip.load(2337, &[key.len() as u8], None);
    chip.load(2338, &key, None);
    chip.load(0x200, include_bytes!("task.ch8"), None);

    loop {
        match chip.cpu_tick() {
            Ok(()) => {},
            Err(_) => {break},
        }
    }

    let result = chip.get_memory(2336);

    if result == 1 {
        println!("What are you waiting for?");
    } else {
        println!("Wrong key.");
    }
}
